package bussineskhata.com;
class AdHelper{static void attach(android.app.Activity a,android.widget.FrameLayout r){}}
