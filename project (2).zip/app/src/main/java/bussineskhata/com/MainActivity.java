package bussineskhata.com;
import android.annotation.SuppressLint;import android.app.AlertDialog;import android.content.Intent;import android.graphics.Bitmap;import android.graphics.Color;import android.graphics.Outline;import android.graphics.PorterDuff;import android.net.ConnectivityManager;import android.net.NetworkInfo;import android.net.Uri;import android.os.Build;import android.os.Bundle;import android.view.Gravity;import android.view.View;import android.view.ViewOutlineProvider;import android.view.WindowManager;import android.webkit.*;import android.widget.*;import androidx.activity.OnBackPressedCallback;import androidx.appcompat.app.AppCompatActivity;import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
public class MainActivity extends AppCompatActivity{
static final boolean STATUS=false,ACTION=false,KEEP=false,CUTOUT=false,DESKTOP=false,WM=false,PULL=true,NONET=true,LOADER=true,BACK=true,EXIT=true,JS=true,DOM=true,FA=true,CA=true,UFA=true,FFU=true,ZOOM=true,SPLASH=true,ADS=false,BAR=false;
static final int DUR=4,FADE=400,ISZ=120,ICR=16,LSZ=48,SPC=28,THK=4;
static final String BG="#1E2227",COLOR="#2ECC71",SBG="#0F1318",LCOL="#00E5CC",SRC="file:///android_asset/index.html";
static final String[] PERMS={"android.permission.READ_EXTERNAL_STORAGE","android.permission.CAMERA"};
WebView web;ProgressBar bar;FrameLayout root;SwipeRefreshLayout swipe;ValueCallback<Uri[]> fcb;
int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
boolean online(){try{ConnectivityManager m=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);NetworkInfo n=m.getActiveNetworkInfo();return n!=null&&n.isConnected();}catch(Exception e){return true;}}
@SuppressLint("SetJavaScriptEnabled")
@Override protected void onCreate(Bundle sv){
super.onCreate(sv);
if(KEEP)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
if(!STATUS)getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
if(CUTOUT&&!ACTION&&Build.VERSION.SDK_INT>=28){WindowManager.LayoutParams p=getWindow().getAttributes();p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;getWindow().setAttributes(p);}
root=new FrameLayout(this);root.setBackgroundColor(Color.parseColor(BG));
web=new WebView(this);
WebSettings s=web.getSettings();
s.setJavaScriptEnabled(JS);s.setDomStorageEnabled(DOM);s.setAllowFileAccess(FA);s.setAllowContentAccess(CA);
s.setAllowUniversalAccessFromFileURLs(UFA);s.setAllowFileAccessFromFileURLs(FFU);
s.setBuiltInZoomControls(ZOOM);s.setSupportZoom(ZOOM);s.setDisplayZoomControls(false);
s.setMediaPlaybackRequiresUserGesture(false);s.setGeolocationEnabled(true);
if(DESKTOP){s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");s.setUseWideViewPort(true);s.setLoadWithOverviewMode(true);}
web.setWebViewClient(new WebViewClient(){
@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){String u=r.getUrl().toString();if(u.startsWith("http")||u.startsWith("file")||u.startsWith("about")||u.startsWith("javascript"))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,r.getUrl()));}catch(Exception e){}return true;}
@Override public void onPageStarted(WebView v,String u,Bitmap f){if(LOADER)bar.setVisibility(View.VISIBLE);}
@Override public void onPageFinished(WebView v,String u){bar.setVisibility(View.GONE);if(swipe!=null)swipe.setRefreshing(false);}
@Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError er){if(NONET&&r.isForMainFrame()&&!online())new AlertDialog.Builder(MainActivity.this).setTitle("No internet").setMessage("Check your connection and try again.").setPositiveButton("Retry",(d,w)->web.reload()).setNegativeButton("Close",null).show();}
});
web.setWebChromeClient(new WebChromeClient(){
@Override public void onProgressChanged(WebView v,int p){bar.setProgress(p);}
@Override public void onPermissionRequest(final PermissionRequest r){runOnUiThread(()->r.grant(r.getResources()));}
@Override public void onGeolocationPermissionsShowPrompt(String o,GeolocationPermissions.Callback cb){cb.invoke(o,true,false);}
@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){if(fcb!=null)fcb.onReceiveValue(null);fcb=cb;try{startActivityForResult(p.createIntent(),1);}catch(Exception e){fcb=null;return false;}return true;}
});
web.setDownloadListener((u,ua,cd,mt,len)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){}});
if(PULL){swipe=new SwipeRefreshLayout(this);swipe.addView(web);swipe.setOnRefreshListener(()->web.reload());swipe.setOnChildScrollUpCallback((p,ch)->web.getScrollY()>0);root.addView(swipe);}else root.addView(web);
bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.getProgressDrawable().setColorFilter(Color.parseColor(COLOR),PorterDuff.Mode.SRC_IN);bar.setVisibility(View.GONE);root.addView(bar,new FrameLayout.LayoutParams(-1,dp(3),Gravity.TOP));
if(WM){TextView t=new TextView(this);t.setText("Made with HTML to APK Builder BD");t.setTextSize(9);t.setTextColor(0x88888888);root.addView(t,new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.END));}
if(ADS)AdHelper.attach(this,root);
if(SPLASH)splash();
setContentView(root);
root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,ACTION?0:i.getSystemWindowInsetTop(),0,i.getSystemWindowInsetBottom());return i;});
getOnBackPressedDispatcher().addCallback(this,new OnBackPressedCallback(true){@Override public void handleOnBackPressed(){if(BACK&&web.canGoBack()){web.goBack();return;}if(EXIT)new AlertDialog.Builder(MainActivity.this).setMessage("Exit app?").setPositiveButton("Yes",(d,w)->finish()).setNegativeButton("No",null).show();else finish();}});
if(Build.VERSION.SDK_INT>=23&&PERMS.length>0)requestPermissions(PERMS,2);
web.loadUrl(SRC);
}
void splash(){final LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER);l.setBackgroundColor(Color.parseColor(SBG));l.setClickable(true);
ImageView iv=new ImageView(this);iv.setImageResource(R.drawable.splash);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setClipToOutline(true);
iv.setOutlineProvider(new ViewOutlineProvider(){@Override public void getOutline(View v,Outline o){o.setRoundRect(0,0,v.getWidth(),v.getHeight(),dp(ICR));}});
l.addView(iv,new LinearLayout.LayoutParams(dp(ISZ),dp(ISZ)));
l.addView(new View(this),new LinearLayout.LayoutParams(1,dp(SPC)));
ProgressBar pb;
if(BAR){pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setIndeterminate(true);l.addView(pb,new LinearLayout.LayoutParams(dp(LSZ*2),dp(THK)));}
else{pb=new ProgressBar(this);l.addView(pb,new LinearLayout.LayoutParams(dp(LSZ),dp(LSZ)));}
pb.getIndeterminateDrawable().setColorFilter(Color.parseColor(LCOL),PorterDuff.Mode.SRC_IN);
root.addView(l,new FrameLayout.LayoutParams(-1,-1));
l.postDelayed(()->l.animate().alpha(0f).setDuration(FADE).withEndAction(()->root.removeView(l)).start(),DUR*1000L);}
@Override protected void onActivityResult(int rq,int rs,Intent d){if(rq==1&&fcb!=null){fcb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs,d));fcb=null;}else super.onActivityResult(rq,rs,d);}
}
