APP BUILDER PRO - Android project

APK/AAB বানানোর উপায়:
1) Android Studio: Open এ এই ফোল্ডার খুলুন, Build > Build APK(s)
2) GitHub: project.zip repository তে আপলোড করুন এবং অ্যাপ থেকে নেওয়া build.yml দিয়ে .github/workflows/build.yml ফাইল বানান।

কমান্ড লাইন: gradle bundleRelease

সাইন: Debug key দিয়ে সাইন হবে (ইনস্টল করা যাবে, Play Store এ দেওয়া যাবে না)।
